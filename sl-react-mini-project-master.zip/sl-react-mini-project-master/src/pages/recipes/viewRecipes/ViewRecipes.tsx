import React  from "react";
import { Modal, Image , Flex, Row, Col } from 'antd';
import './ViewRecipesStyle.scss';
import {CustomTitle, CustomLabel} from "../../../components/Typograghy/Typography";
import DynamicIcon from "../../../components/Icons/DynamicIcon";
import { useSelector } from "react-redux";
import { RootState } from "../../../redux/store/Store";
import ViewSpecials from "./viewSpecials/ViewSpecials";

//CUSTOM MODAL
function ViewRecipes(props:any) {
    const viewRecipe = useSelector<RootState, any>((state: RootState) => state.recipe.viewRecipes)
    const handleFilteredSpecials = (recipeUuid:string) => {
        return <ViewSpecials recipeUuid={recipeUuid} />
    }
    return ( 
        <div className="view-recipes">
            {
                viewRecipe && 
                    ( 
                        <Modal centered title="" open={props.open} onCancel={props.close} maskClosable={props.close} footer={props.footer} className="view-recipes-modal" width={1000}>
                            <Flex gap="middle" align="flex-start" justify="flex-start">
                                <div>
                                    <Image src={viewRecipe?.images?.small} alt="recipe medium"/>
                                </div>
                                <div>
                                    <CustomTitle title={viewRecipe?.title} type="h4"/>
                                    <CustomTitle title={viewRecipe?.description} type="h5"/>
                                    <Flex gap="middle">
                                        <div>
                                            <CustomTitle title="Post Date: " type="h6"/>
                                            <CustomLabel label={viewRecipe?.postDate} />
                                        </div>
                                        <div>
                                            <CustomTitle title="Edit Date: " type="h6"/>
                                            <CustomLabel label={viewRecipe?.editDate} />
                                        </div>
                                    </Flex>
                                </div>
                            </Flex>
                            <Row>
                                <Col span={8}>
                                <div>
                                    <CustomTitle title="Ingredients" type="h6"/>
                                    {viewRecipe?.ingredients?.map((item:any, id:string) => {
                                        return (
                                            <ul key={id}>
                                                <li>
                                                    <Flex gap="middle" align="center" justify="space-between">
                                                        <div>{item.name}</div>
                                                        <div>{handleFilteredSpecials(item.uuid)}</div>
                                                    </Flex>
                                                    <ul>
                                                        <li>{item.amount}</li>
                                                        {item.measurement && <li>{item.measurement}</li>}
                                                    </ul>
                                                </li>
                                            </ul>
                                        );
                                    })}
                                </div>
                                </Col>
                                <Col span={16}>
                                <div>
                                    <CustomTitle title="Directions" type="h6"/>
                                    {viewRecipe?.directions?.map((item:any, id:string) => {
                                        return (
                                            <ul key={id}>
                                                <li>{item.instructions}</li>
                                            </ul>
                                        );
                                    })}
                                </div>
                                </Col>
                            </Row>
                    </Modal> 
                ) 
            }
        </div>
    );
}

export default ViewRecipes;