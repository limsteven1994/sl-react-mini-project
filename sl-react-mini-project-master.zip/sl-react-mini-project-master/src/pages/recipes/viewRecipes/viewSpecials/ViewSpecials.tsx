import React from "react";
import "./ViewSpecialStyle.scss"
import { Popover , Flex } from "antd";
import DynamicIcon from "../../../../components/Icons/DynamicIcon";
import { useSelector } from "react-redux";
import { RootState } from "../../../../redux/store/Store";
import {CustomTitle,CustomLabel } from "../../../../components/Typograghy/Typography";
function ViewSpecials(props:any) {
    const getAllSpecials = useSelector<RootState, any>((state: RootState) => state.special.specials)
    const filteredSpecials = getAllSpecials.find((item:any) => item.ingredientId === props.recipeUuid);
    return filteredSpecials &&
        <div className="view-special">
            <Popover
                placement="right"
                trigger="hover"
                title={
                    <div className="special-title">
                        <CustomTitle title={filteredSpecials.title} type="h6"/>
                    </div>
                }
                content={
                    <div className="special-details">
                        <Flex gap="small">
                            <div>
                                <CustomTitle title="Type:" type="h6"/>
                                <CustomLabel label={filteredSpecials?.type} size="medium"/>
                            </div>
                            <div>
                                <CustomTitle title={"Details:"} type="h6"/>
                                <CustomLabel label={filteredSpecials?.text} size="medium"/>
                            </div>
                        </Flex>
                    </div>
                }
            >
                <div className="special-offer">
                    <DynamicIcon type={"FieldTimeOutlined"} size="20" className="special-star-icon" />
                    <CustomLabel label="&nbsp;LIMITED OFFER"/>
                </div>
            </Popover>
        </div>
}

export default ViewSpecials;
