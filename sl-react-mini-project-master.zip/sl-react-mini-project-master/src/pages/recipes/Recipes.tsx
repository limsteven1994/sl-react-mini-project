import "./RecipesStyle.scss";
import React, { useState, useEffect, ReactNode, Key } from "react";

import { Rate, Flex, Statistic } from "antd";
import { RECIPE_INTERFACE } from "../../interfaces/RecipesInterface";
import { GET_RECIPE_API } from "../../api/Recipes_api";
import { GET_SPECIAL_API } from "../../api/Special_api";
import {CustomLabel , CustomTitle} from "../../components/Typograghy/Typography";
import DynamicIcon from "../../components/Icons/DynamicIcon";
import ViewRecipes from "./viewRecipes/ViewRecipes";
import RecipeSkeleton from "../../components/skeleton/RecipeSkeleton";
import { useSelector, useDispatch } from "react-redux";
import { AppDispatch, RootState } from "../../redux/store/Store";
import { viewRecipes, getRecipesStatus } from "../../redux/slice/RecipeSlice";
import { getSpecialStatus } from "../../redux/slice/SpecialSlice";
import GlobalError from "../errorPage/GlobalError";
function Recipes() {
    // const [recipes, setRecipes] = useState<RECIPE_INTERFACE[]>([]);
    const [showRecipes, setShowRecipes] = useState<boolean>(false);
    //const [currentRecipes, setCurrentRecipes] = useState<Object>([]);
    const handleRecipe = (data: object) => (event: any) => {
        setShowRecipes(true);
        dispatch(viewRecipes(data))
    };
    const dispatch = useDispatch<AppDispatch>();
    const getAllRecipe = useSelector((state: RootState) => state.recipe.recipes)
    const viewRecipe = useSelector((state: RootState) => state.recipe.viewRecipes)
    const recipeStatus = useSelector(getRecipesStatus);
    const specialStatus = useSelector(getSpecialStatus);

    useEffect(() => {
        setTimeout(() => {
            if (recipeStatus === "idle") {
                dispatch(GET_RECIPE_API());
            }
            if (specialStatus === "idle") {
                dispatch(GET_SPECIAL_API());
            }
        }, 3000);
    }, [recipeStatus,specialStatus, dispatch]);
    let contentToDisplay: ReactNode;
    if (['idle','loading'].indexOf(recipeStatus) !== -1) {
        contentToDisplay =  <RecipeSkeleton active={recipeStatus}/>;
    } 
    else if (recipeStatus === 'success') {
        contentToDisplay = getAllRecipe.map((recipe: RECIPE_INTERFACE,id: Key) => (
            <div className="custom-card" style={{ backgroundImage: `url(${recipe.images.small})` }} key={id} onClick={handleRecipe(recipe)}>
                <div className="custom-card-body">
                    <Flex gap="middle"className="recipe-details" justify="space-between" align="center">
                        <div>
                            <img src={recipe.images.medium} alt="recipe"/>
                        </div>
                        <div>
                            <CustomTitle title={recipe.title} type="h3"/>
                            <Rate disabled defaultValue={Math.floor(Math.random() * 5) + 1 } />
                            <Statistic title="Total Review" value={Math.floor(100000 + Math.random() * 900000)} />
                            <div className="recipe-description">
                                <CustomLabel label={recipe.description} size="medium"/>
                            </div>
                                <Flex gap="middle" justify="center" align="end">
                                    <div>
                                        <DynamicIcon type={'PieChartOutlined'} size="20"/>
                                    </div>
                                    <div>
                                        <CustomLabel label="Servings:" size="medium"/>
                                    </div>
                                    <div>
                                        <CustomLabel label={recipe.servings}/>
                                    </div>
                                    <div>
                                        <DynamicIcon type={'BookOutlined'} size="19"/>
                                    </div>
                                    <div>
                                        <CustomLabel label="Preparation Time:" size="medium"/>
                                    </div>
                                    <div>
                                        <CustomLabel label={recipe.prepTime}/>
                                    </div>
                                    <div>
                                        <DynamicIcon type={'ClockCircleOutlined'} size="20" />
                                    </div>
                                    <div>
                                        <CustomLabel label="Cooking Time:" size="medium"/>
                                    </div>
                                    <div>
                                        <CustomLabel label={recipe.cookTime}/>
                                    </div>
                                </Flex>
                        </div>
                    </Flex>
                </div>
            </div>
        ))
    } 
    else {
        contentToDisplay = <GlobalError/>;
    }
    return ( 
        <div>
            <Flex gap="middle" vertical className="Recipes">
            {contentToDisplay}
        </Flex>
        {viewRecipe && ( <ViewRecipes open={showRecipes} close={() => setShowRecipes(false)} footer={null}  />
            )}
        </div>
        
    ) 
}
export default Recipes;
