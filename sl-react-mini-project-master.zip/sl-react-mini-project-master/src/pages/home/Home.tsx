import React from "react";
import { Flex } from "antd";
function Home(){
    return (
        <Flex gap="middle" justify="center" align="center">
            <div>
                <label>Home</label>
            </div>
        </Flex>
    );
};

export default Home;
