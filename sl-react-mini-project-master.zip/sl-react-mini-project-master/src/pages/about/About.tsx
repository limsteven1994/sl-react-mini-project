import React from "react";
import { Flex } from "antd";
function About() {
    return ( 
        <Flex gap="middle" justify="center" align="center">
        <div>
            <label>About</label>
        </div>
    </Flex>
    );
}
export default About;