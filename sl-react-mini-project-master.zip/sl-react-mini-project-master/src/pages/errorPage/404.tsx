import React from "react";
import { Flex, Result } from "antd";
function ErrorPage404() {
    // const error = useRouteError();
    // console.error(error);
    return (
        <Flex gap="middle" justify="center" align="center">
            <div id="error-page">
            <Result
                status="404"
                title="404"
                subTitle="Sorry, the page you visited does not exist."
            />
            </div>
        </Flex>
    );
}
export default ErrorPage404;
