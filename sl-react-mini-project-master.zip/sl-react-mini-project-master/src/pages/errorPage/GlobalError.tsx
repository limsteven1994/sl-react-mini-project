import React from "react";
import { Result } from "antd";
const GlobalError = () => {
    return (
        <div>
            <Result
                status="warning"
                title="There are some problem with the operation. Please try again later."
                // extra={
                //     <Button type="primary" key="console">
                //         Go Console
                //     </Button>
                // }
            />
        </div>
    );
};

export default GlobalError;
