import React from "react";
import "./TopNavigationStyle.scss";
import { Tabs } from "antd";
import { TOP_NAVIGATION_DATA } from "../../constant/TopNavigation.d";
import { Link } from 'react-router-dom';
// const onChange = (key: string) => {
//     console.log(key);
// };
function TopNavigation() {
    return (
        <Tabs
            defaultActiveKey="1"
            className="TopNavigationStyle"
            size={"large"}
            items={TOP_NAVIGATION_DATA.map((item, i) => {
                return {
                    key: item.key,
                    label: <Link to={item.path}>{item.label} </Link>,
                    icon: item.icon,
                };
            })}
            // onChange={onChange}
        />
)};

export default TopNavigation;
