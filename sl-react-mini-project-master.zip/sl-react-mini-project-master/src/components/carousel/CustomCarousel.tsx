import React from "react";
import { Carousel, Flex } from "antd";
import "./CustomCarouselStyle.scss";
import { Images } from "../../constant/Images.d";
const CarouselImagesArray = Images;

function CustomCarousel() {
    return (
        <Flex>
            <Carousel effect="fade" autoplay dotPosition="right">
                {CarouselImagesArray.map((item, id) => {
                    return (
                        <div className="customCarouselStyle" key={id}>
                            <img src={item} alt={item} />
                        </div>
                    );
                })}
            </Carousel>
        </Flex>
    );
}
export default CustomCarousel;
