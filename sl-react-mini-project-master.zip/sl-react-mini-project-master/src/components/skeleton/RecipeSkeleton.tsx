import React from "react";
import { Skeleton, Row, Col, Flex , Space } from "antd";
import "./RecipeSkeletonStyle.scss";
const RecipeSkeleton = (props: any) => {
    return (
        <div className="RecipeSkeleton">
            <div className="custom-card-skeleton">
                <div className="custom-card-body-skeleton">
                    <Row>
                        <Col span={12}>
                            <Skeleton.Image active={props.active} />
                        </Col>
                        <Col span={12} className="recipe-details-skeleton" >
                        <Flex gap="middle" justify="flex-end" align="end">
                            <div>
                                <br />
                                <Space>
                                    <Skeleton.Input active  size="default" /> 
                                </Space>
                                <br/><br />
                                <Space>
                                    <Skeleton.Input active size="default" block={true} />
                                </Space>
                                <br/><br/>
                                <Space>
                                    <Skeleton.Input active size="default" />
                                </Space>
                                <br/><br/>
                            </div>
                        </Flex>
                        <Flex gap="middle" justify="flex-end" align="end" >
                            <div>
                                <Skeleton.Input active size="small" block={true}/>
                            </div>
                            <div>
                                <Skeleton.Input active size="small" block={true}/>
                            </div>
                            <div>
                                <Skeleton.Input active size="small" block={true}/>
                            </div>
                        </Flex>
                        </Col>
                    </Row>
                    {/* <Flex gap="middle" align="center" justify="center" vertical>
                    <Skeleton active paragraph={{ rows: 2 }} />
                    </Flex> */}
                    {/* <Flex gap="middle" align="center" justify="center" vertical>
                            <Skeleton.Input active size="small" block={true}/>
                            <Skeleton.Input active size="small" block={true}/>
                            <Skeleton.Input active size="small" block={true}/>
                            <Skeleton.Input active size="small" block={true}/>
                        </Flex> */}
                </div>
            </div>
        </div>
    );
};
export default RecipeSkeleton;
