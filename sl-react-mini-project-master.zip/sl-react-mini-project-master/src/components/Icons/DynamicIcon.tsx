import React, { lazy , Suspense } from 'react';
import { LoadingOutlined } from '@ant-design/icons';
import { Spin } from 'antd';
function DynamicIcon(props:any) {
    const AntdIcon = lazy(() => import(`@ant-design/icons/es/icons/${props.type}.js`))
    return ( 
        <Suspense fallback={<div><Spin indicator={<LoadingOutlined style={{ fontSize: 20 }} spin />} /></div>}>
        <AntdIcon
            onClick={props.onClick}
            style={{ ...props.style, fontSize: `${props.size}px`, color: props.className ?  props.color  : 'white' }} 
            className={props.className}
        />
        </Suspense>
    );
}


export default DynamicIcon ;