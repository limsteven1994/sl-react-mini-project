import React from 'react';
import "./TypographyStyle.scss";
function CustomLabel(props:any) {
        return (
            <span className={props.className || 'CustomLabel'}>
                <label className={props.size || 'default'}>{props.label}</label>
            </span>
        );
    }

// function CustomTitle(props:any) {
//     return (
//         <div className={'CustomTitle' || props.className} style={{ fontSize : `${props.fontSize}px`, color : props.color ? props.color : 'black', fontWeight: props.fontWeight }}>
//             <span>{props.title}</span>
//         </div>
//     );
// }


function CustomTitle(props:any) {
    return (
        <span className={props.className || 'CustomTitle'}>
            {props.type === 'h1' && <h1>{props.title}</h1>}
            {props.type === 'h2' && <h2>{props.title}</h2>}
            {props.type === 'h3' && <h3>{props.title}</h3>}
            {props.type === 'h4' && <h4>{props.title}</h4>}
            {props.type === 'h5' && <h5>{props.title}</h5>}
            {props.type === 'h6' && <h6>{props.title}</h6>}
        </span>
    );
}

export { CustomLabel , CustomTitle } ;