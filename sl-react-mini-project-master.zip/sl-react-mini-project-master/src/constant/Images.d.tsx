import topImage from "../../public/img/topImage.png";
import queso_brat_scramble_s from "../../public/img/queso_brat_scramble--s.jpg";
import queso_brat_scramble_m from "../../public/img/queso_brat_scramble--m.jpg";
import queso_brat_scramble from "../../public/img/queso_brat_scramble.jpg";

import italian_meatballs_s from "../../public/img/italian_meatballs--s.jpg";
import italian_meatballs_m from "../../public/img/italian_meatballs--m.jpg";
import italian_meatballs from "../../public/img/italian_meatballs.jpg";

import kielbasa_skillet_s from "../../public/img/kielbasa_skillet--s.jpg";
import kielbasa_skillet_m from "../../public/img/kielbasa_skillet--m.jpg";
import kielbasa_skillet from "../../public/img/kielbasa_skillet.jpg";

import brussel_chips_s from "../../public/img/brussel_chips--s.jpg";
import brussel_chips_m from "../../public/img/brussel_chips--m.jpg";
import brussel_chips from "../../public/img/brussel_chips.jpg";


import pancake_mountain_s from "../../public/img/pancake_mountain--s.jpg";
import pancake_mountain_m from "../../public/img/pancake_mountain--m.jpg";
import pancake_mountain from "../../public/img/pancake_mountain.jpg";




const Images = [
    topImage,
    queso_brat_scramble,
    italian_meatballs,
    kielbasa_skillet,
    brussel_chips_s,
    brussel_chips,
    pancake_mountain
];

export {  topImage,
    
    queso_brat_scramble_s,
    queso_brat_scramble_m,
    queso_brat_scramble,

    italian_meatballs_s,
    italian_meatballs_m,
    italian_meatballs,

    kielbasa_skillet_s,
    kielbasa_skillet_m,
    kielbasa_skillet,

    brussel_chips_s,
    brussel_chips_m,
    brussel_chips,

    pancake_mountain_s,
    pancake_mountain_m,
    pancake_mountain,
    Images }