import React from "react";
import { HomeFilled , SnippetsFilled, PhoneFilled, IdcardFilled } from "@ant-design/icons";
import { TOP_NAVIGATION_INTERFACE } from "../interfaces/TopNavigationInterfaces";
const TOP_NAVIGATION_DATA:  TOP_NAVIGATION_INTERFACE[] = [
    {
        key: '1',
        label:"HOME",
        path:"/",
        icon: <HomeFilled />
    },
    {
        key:'2',
        label:"RECIPES",
        path:"/recipes",
        icon: <SnippetsFilled />
    },
    {
        key:'3',
        label:"ABOUT",
        path:"/about",
        icon: <IdcardFilled />
    },
    {
        key:'4',
        label:"CONTACT US",
        path:"/contact",
        icon: <PhoneFilled />
    }
];

export { TOP_NAVIGATION_DATA };