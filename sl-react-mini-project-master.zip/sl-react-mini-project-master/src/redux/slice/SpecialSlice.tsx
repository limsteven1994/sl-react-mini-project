import React from 'react'
import { createSlice } from "@reduxjs/toolkit";
import { GET_SPECIAL_API } from "../../api/Special_api";

const initialState = {
    specials: [],
    status: "idle",
    error: undefined,
};

export const specialSlice = createSlice({
    name: "special",
    initialState,
    reducers: { },
    extraReducers: (builder) => {
        builder.addCase(GET_SPECIAL_API.pending, (state) => {
            state.status = 'loading';
        });
        builder.addCase(GET_SPECIAL_API.fulfilled, (state, action) => {
            state.status = 'success';
            state.specials = action.payload;
        });
        builder.addCase(GET_SPECIAL_API.rejected, (state, action) => {
            state.status = 'failed';
            //state.error = action.error.message
        });
    },
});
// Action creators are generated for each case reducer function
export const {} = specialSlice.actions;

export const getSpecialStatus = (state: { special: { status: string; }; }) => state.special.status;
export const getSpecialError = (state: { special: { error: any; }; }) => state.special.error;

export default specialSlice.reducer;