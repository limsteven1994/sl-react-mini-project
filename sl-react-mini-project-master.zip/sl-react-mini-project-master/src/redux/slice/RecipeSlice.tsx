import { createSlice } from "@reduxjs/toolkit";
import { GET_RECIPE_API } from "../../api/Recipes_api";

const initialState = {
    recipes: [],
    viewRecipes:{},
    status: "idle",
    error: undefined,
};

export const recipeSlice = createSlice({
    name: "recipe",
    initialState,
    reducers: {
        viewRecipes(state, action) {
            return {
                ...state,
                viewRecipes: action.payload,
            };
        },
    },
    extraReducers: (builder) => {
        builder.addCase(GET_RECIPE_API.pending, (state) => {
            state.status = 'loading';
        });
        builder.addCase(GET_RECIPE_API.fulfilled, (state, action) => {
            state.status = 'success';
            state.recipes = action.payload;
        });
        builder.addCase(GET_RECIPE_API.rejected, (state, action) => {
            state.status = 'failed';
            //state.error = action.error.message
        });
    },
});
// Action creators are generated for each case reducer function
export const { viewRecipes } = recipeSlice.actions;

export const getRecipesStatus = (state: { recipe: { status: string; }; }) => state.recipe.status;
export const getRecipesError = (state: { recipe: { error: any; }; }) => state.recipe.error;

export default recipeSlice.reducer;
