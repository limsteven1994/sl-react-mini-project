export interface RECIPE_INTERFACE {
    uuid:        string;
    title:       string;
    description: string;
    images:      Images;
    servings:    number;
    prepTime:    number;
    cookTime:    number;
    postDate:    string;
    editDate:    string;
    ingredients: Ingredient[];
    directions:  Direction[];
}

export interface Direction {
    instructions: string;
    optional:     boolean;
}

export interface Images {
    full:   string;
    medium: string;
    small:  string;
}

export interface Ingredient {
    uuid:        string;
    amount:      number | null;
    measurement: string;
    name:        string;
}