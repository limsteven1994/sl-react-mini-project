export interface SPECIAL_INTERFACE {
    uuid:         string;
    ingredientId: string;
    type:         string;
    title:        string;
    geo:          string;
    text:         string;
    id:           string;
}