export interface TOP_NAVIGATION_INTERFACE {
    key: string;
    path: string;
    label:string;
    icon: any;
}
