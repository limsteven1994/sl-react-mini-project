import axios from "axios";
import { createAsyncThunk } from "@reduxjs/toolkit";
import { API_BASE_URL } from "../constant/Global.d";

const RECIPE_URL = API_BASE_URL+'/recipes';
const GET_RECIPE_API = createAsyncThunk(
    "recipe",
    async () => {
        try {
            const response = await axios.get(RECIPE_URL);
            return response.data;
        } catch (error) {
            console.error(error);
        }
    }
);

export { GET_RECIPE_API };
