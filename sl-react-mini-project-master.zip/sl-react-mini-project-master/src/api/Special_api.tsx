import axios from "axios";
import { createAsyncThunk } from "@reduxjs/toolkit";
import { API_BASE_URL } from "../constant/Global.d";

const SPECIAL_URL = API_BASE_URL+'/specials';
const GET_SPECIAL_API = createAsyncThunk(
    "specials",
    async () => {
        try {
            const response = await axios.get(SPECIAL_URL);
            return response.data;
        } catch (error) {
            console.error(error);
        }
    }
);

export { GET_SPECIAL_API };
