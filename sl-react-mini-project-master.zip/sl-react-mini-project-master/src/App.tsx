import React from "react";
import MainRouter from "./routes/MainRouter";
import "./../public/styles/App.scss";
import MainLayout from "./layout/mainLayout/MainLayout";
function App() {
    return (
        <div>
            <MainLayout />
        </div> 
        
    );
}

export default App;
