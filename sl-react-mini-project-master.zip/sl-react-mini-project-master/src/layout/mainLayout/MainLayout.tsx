import React from "react";
import { Layout, Flex } from "antd";
import Header from "../header/Header";
import Content from "../content/Content";
import Footer from "../footer/Footer";
import MainRouter from "../../routes/MainRouter";
import "./MainLayoutStyle.scss";
import CustomCarousel from "../../components/carousel/CustomCarousel";

function MainLayout() {
    return (
        <div>
            <Flex gap="middle">
                <Layout className="mainLayoutStyle">
                    <CustomCarousel />
                    <Header />
                    <MainRouter/>
                    {/* <Content/> */}
                    <Footer/>
                </Layout>
            </Flex>
        </div>
    );
}
export default MainLayout;
