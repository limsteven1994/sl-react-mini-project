import React from "react";
import "./FooterStyle.scss";
import { Flex } from "antd";
import DynamicIcon from "../../components/Icons/DynamicIcon";
import { CustomTitle } from "../../components/Typograghy/Typography";
function Footer() {
return (
        <div className="footerStyle">
            <Flex gap="middle" align="center" justify="center">
                <div>
                    <DynamicIcon type ={'TrademarkCircleFilled'} size="20"/>
                    <CustomTitle className="footer-title" title="SL MINI REACT + REDUX PROJECT @2024" type="h5" />
                </div>
            </Flex>
        </div>
    )
}

export default Footer;