import React from "react";
import "./HeaderStyle.scss";
import { Flex } from "antd";
import TopNavigation from "../../components/topNavigation/TopNavigation";
function Header() {
    return (
        <div className="headerStyle">
            <Flex gap="middle" align="center" vertical>
                <TopNavigation />
            </Flex>
        </div>
    );
}
export default Header;
