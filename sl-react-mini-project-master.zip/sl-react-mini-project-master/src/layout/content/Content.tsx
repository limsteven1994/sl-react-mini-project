import React from "react";
import "./ContentStyle.scss";

function Content() {
    return (
        <div className="contentStyle">Cotent</div>
    );
}

export default Content;