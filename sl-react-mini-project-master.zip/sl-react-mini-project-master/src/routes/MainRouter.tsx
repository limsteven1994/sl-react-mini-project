import React from "react";
import { useRoutes } from "react-router-dom";

//IMPORT MAIN LAYOUT
//import MainLayout from "../layout/mainLayout/MainLayout";

//IMPORT PAGES
import Home from "../pages/home/Home";
import Recipes from "../pages/recipes/Recipes";
import About from "../pages/about/About";
import Contact from "../pages/contact/Contact";
//MAIN ROUTES
import ErrorPage from "../pages/errorPage/404";

function MainRouter() {
    const element = useRoutes([
      { path:"/", element: <Home/> },
      { path: "/recipes", element: <Recipes/>,
        // children: [
        //   { index: true, path:'TBD', element: <TBD/> },
        // ],
      },
      { path: "/about", element: <About/> },
      { path: "/contact", element: <Contact/> },
      { path: "*", element: <ErrorPage/>}
    ]);
    return element;
  }

  export default MainRouter;