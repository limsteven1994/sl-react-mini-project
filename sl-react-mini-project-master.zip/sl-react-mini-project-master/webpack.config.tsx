var HtmlWebpackPlugin = require("html-webpack-plugin");
const path = require("path");

module.exports = {
    mode: "development",
    module: {
        rules: [
            {
                test: /\.jsx?$/,
                loader: "babel-loader",
            },
            {
                test: /\.less$/,
                use: [
                    { loader: "style-loader" },
                    { loader: "css-loader" },
                    { loader: "less-loader" },
                    { loader: "sass-loader" },
                    // {
                    //     loader: "text-transform-loader",
                    //     options: {
                    //         prependText:
                    //             '@import "../public/styles/Colors.less"',
                    //     },
                    // },
                ],
            },
        ],
    },
    resolve: {
        extensions: [".js", ".jsx", "tsx"],
        alias: {
            "@": path.resolve(__dirname, "src/"),
        },
    },
    plugins: [
        new HtmlWebpackPlugin({
            template: "./src/index.html",
        }),
    ],
    devServer: {
        historyApiFallback: true,
    },
    externals: {
        // global app config object
        config: JSON.stringify({
            apiUrl: "http://localhost:3000",
        }),
    },
};
